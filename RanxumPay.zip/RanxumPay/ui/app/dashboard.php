<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escrow Payment Dashboard</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .escrow-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 800px;
            margin-bottom: 80px; /* Space for bottom bar */
        }
        .main-balance-card {
            background: linear-gradient(135deg, #6610f2, #4d0cb5);
            color: white;
            border-radius: 15px;
            padding: 2rem;
        }
        .dashboard-item {
            padding: 1rem;
            border-radius: 10px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .dashboard-item:hover {
            background: #f8f9fa;
            transform: translateY(-5px);
        }
        .dashboard-icon {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            background: rgba(102, 16, 242, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1rem;
            color: #6610f2;
        }
        .bottom-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            padding: 1rem;
            display: flex;
            justify-content: space-around;
            z-index: 1000;
        }
        .bottom-bar-item {
            text-align: center;
            color: #6610f2;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .bottom-bar-item:hover {
            transform: translateY(-5px);
        }
        .bottom-bar-icon {
            font-size: 1.25rem;
        }
        .bottom-bar-label {
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center">

<div class="escrow-card p-4 m-3">
    <!-- Header -->
    <div class="text-center mb-4">
        <h2 class="text-purple">
            <i class="bi bi-shield-lock me-2"></i>
            Escrow Payment Dashboard
        </h2>
        <p class="text-muted">Manage your escrow payments securely</p>
    </div>

    <!-- Main Balance Card -->
    <div class="main-balance-card mb-4">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <div class="text-muted small">Available Balance</div>
                <div class="h1">$12,500.00</div>
            </div>
            <i class="bi bi-wallet2 fs-1"></i>
        </div>
    </div>

    <!-- Transaction History -->
    <div class="dashboard-item mb-3">
        <div class="d-flex align-items-center">
            <div class="dashboard-icon me-3">
                <i class="bi bi-clock-history"></i>
            </div>
            <div>
                <h6 class="mb-1">Transaction History</h6>
                <p class="text-muted small mb-0">View all past transactions</p>
            </div>
        </div>
    </div>

    <!-- Confirm/Reject Payment -->
    <div class="dashboard-item">
        <div class="d-flex align-items-center">
            <div class="dashboard-icon me-3">
                <i class="bi bi-check2-circle"></i>
            </div>
            <div>
                <h6 class="mb-1">Confirm/Reject Payment</h6>
                <p class="text-muted small mb-0">Manage pending payments</p>
            </div>
        </div>
    </div>

    <!-- Additional Information -->
    <div class="alert alert-primary mt-4">
        <div class="row">
            <div class="col-md-6">
                <i class="bi bi-info-circle me-2"></i>
                Escrow ensures secure transactions
            </div>
            <div class="col-md-6">
                <i class="bi bi-shield-check me-2"></i>
                Your funds are protected
            </div>
        </div>
    </div>
</div>

<!-- Bottom Bar -->
<div class="bottom-bar">
    <!-- Add Payee -->
    <div class="bottom-bar-item">
        <div class="bottom-bar-icon">
            <i class="bi bi-person-plus"></i>
        </div>
        <div class="bottom-bar-label">Add Payee</div>
    </div>

    <!-- Load Balance -->
    <div class="bottom-bar-item">
        <div class="bottom-bar-icon">
            <i class="bi bi-wallet2"></i>
        </div>
        <div class="bottom-bar-label">Load Balance</div>
    </div>

    <!-- Transfer Money -->
    <div class="bottom-bar-item">
        <div class="bottom-bar-icon">
            <i class="bi bi-arrow-left-right"></i>
        </div>
        <div class="bottom-bar-label">Transfer Money</div>
    </div>

    <!-- Withdraw Money -->
    <div class="bottom-bar-item">
        <div class="bottom-bar-icon">
            <i class="bi bi-cash-coin"></i>
        </div>
        <div class="bottom-bar-label">Withdraw Money</div>
    </div>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>