<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escrow Payment Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #6f42c1;
            --secondary-color: #ffffff;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            left: -280px;
            transition: all 0.3s;
            background: var(--secondary-color);
            z-index: 1000;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }

        .sidebar.active {
            left: 0;
        }

        .main-content {
            margin-left: 0;
            transition: all 0.3s;
        }

        .main-content.active {
            margin-left: 280px;
        }

        .balance-card {
            background: var(--primary-color);
            color: var(--secondary-color);
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: var(--secondary-color);
            box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
            display: none;
        }

        @media (max-width: 768px) {
            .bottom-nav {
                display: block;
            }
            .sidebar {
                width: 100%;
                left: -100%;
            }
        }

        .nav-link.active {
            background: var(--primary-color);
            color: white !important;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar p-3">
        <h4 class="text-primary mb-4"><i class="bi bi-shield-lock me-2"></i>EscrowPay</h4>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="#"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="#"><i class="bi bi-wallet2 me-2"></i>Wallet</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="#"><i class="bi bi-people me-2"></i>Payees</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-dark" href="#"><i class="bi bi-clock-history me-2"></i>History</a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-light bg-white shadow-sm sticky-top">
            <div class="container-fluid">
                <button class="btn btn-primary" id="menuToggle">
                    <i class="bi bi-list"></i>
                </button>
                <h5 class="mb-0 text-primary">Welcome, Alex!</h5>
            </div>
        </nav>

        <!-- Main Balance -->
        <div class="container mt-4">
            <div class="balance-card p-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="mb-1">Escrow Balance</h6>
                        <h2>$42,560.00</h2>
                        <small class="opacity-75">Available to transact</small>
                    </div>
                    <i class="bi bi-safe2 fs-1 opacity-75"></i>
                </div>
            </div>

            <!-- Transaction History -->
            <div class="card mt-4 border-0 shadow">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="bi bi-receipt me-2"></i>Recent Transactions</h6>
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <span class="badge bg-success me-2"><i class="bi bi-arrow-down"></i></span>
                                Payment from Client A
                            </div>
                            <span class="text-success">+$2,500.00</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <span class="badge bg-danger me-2"><i class="bi bi-arrow-up"></i></span>
                                Escrow release to Vendor X
                            </div>
                            <span class="text-danger">-$1,800.00</span>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Pending Approvals -->
            <div class="card mt-4 border-0 shadow">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0"><i class="bi bi-shield-check me-2"></i>Pending Approvals</h6>
                    <span class="badge bg-primary">2 Requests</span>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h6 class="mb-0">Project Alpha Payment</h6>
                            <small class="text-muted">$5,000.00 • Due tomorrow</small>
                        </div>
                        <div>
                            <button class="btn btn-success btn-sm px-3"><i class="bi bi-check-lg"></i></button>
                            <button class="btn btn-danger btn-sm px-3 ms-2"><i class="bi bi-x-lg"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bottom Navigation -->
        <div class="bottom-nav">
            <div class="container">
                <div class="row py-2 text-center">
                    <div class="col-3">
                        <a href="#" class="text-primary">
                            <i class="bi bi-person-plus fs-5"></i>
                            <small class="d-block mt-1">Add Payee</small>
                        </a>
                    </div>
                    <div class="col-3">
                        <a href="#" class="text-primary">
                            <i class="bi bi-plus-circle fs-5"></i>
                            <small class="d-block mt-1">Load Funds</small>
                        </a>
                    </div>
                    <div class="col-3">
                        <a href="#" class="text-primary">
                            <i class="bi bi-send fs-5"></i>
                            <small class="d-block mt-1">Transfer</small>
                        </a>
                    </div>
                    <div class="col-3">
                        <a href="#" class="text-primary">
                            <i class="bi bi-cash-coin fs-5"></i>
                            <small class="d-block mt-1">Withdraw</small>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
            document.querySelector('.main-content').classList.toggle('active');
        });

        // Close sidebar when clicking outside on desktop
        if (window.innerWidth > 768) {
            document.addEventListener('click', function(e) {
                if (!document.querySelector('.sidebar').contains(e.target) && 
                    !document.getElementById('menuToggle').contains(e.target)) {
                    document.querySelector('.sidebar').classList.remove('active');
                    document.querySelector('.main-content').classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>