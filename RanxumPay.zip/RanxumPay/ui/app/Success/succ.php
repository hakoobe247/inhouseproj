<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success Message</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .success-section {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .success-icon {
            font-size: 4rem;
            animation: bounce 1s ease-in-out;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
    </style>
</head>
<body>

<section class="success-section container-fluid d-flex align-items-center justify-content-center min-vh-100 p-5">
    <div class="text-center">
        <!-- Success Icon -->
        <i class="bi bi-check-circle-fill success-icon text-success mb-4"></i>
        
        <!-- Success Message -->
        <h1 class="mb-3 text-success">Success!</h1>
        <p class="lead mb-4">Your transaction was completed successfully.</p>
        
        
        <!-- Continue Button -->
        <div class="mt-4">
            <a href="#" class="btn btn-success btn-lg">
                <i class="bi bi-arrow-right-circle me-2"></i>
                Continue
            </a>
        </div>
    </div>
</section>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>