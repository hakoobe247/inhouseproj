<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intro Card Carousel</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .intro-carousel {
            padding: 5rem 0;
            background: #f8f9fa;
        }
        .card-slide {
            padding: 2rem;
        }
        .intro-card {
            border: none;
            border-radius: 15px;
            transition: transform 0.3s;
            background: white;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            text-align: center;
            padding: 3rem 2rem;
            margin: 0 auto;
            max-width: 400px;
        }
        .intro-card:hover {
            transform: translateY(-10px);
        }
        .icon-container {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: linear-gradient(45deg, #6c5ce7, #a8a4e6);
            margin: 0 auto 2rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .intro-card i {
            font-size: 2.5rem;
            color: white;
        }
        .carousel-control-prev,
        .carousel-control-next {
            width: 5%;
            color: #6c5ce7;
        }
    </style>
</head>
<body>

<section class="intro-carousel container-fluid">
    <div id="cardCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <!-- Slide 1 -->
            <div class="carousel-item active">
                <div class="card-slide">
                    <div class="intro-card">
                        <div class="icon-container">
                            <i class="bi bi-rocket-takeoff"></i>
                        </div>
                        <h3 class="mb-3">Fast Launch</h3>
                        <p class="text-muted mb-4">Quick start your projects with our efficient platform</p>
                        <a href="#" class="btn btn-primary">Get Started</a>
                    </div>
                </div>
            </div>

            <!-- Slide 2 -->
            <div class="carousel-item">
                <div class="card-slide">
                    <div class="intro-card">
                        <div class="icon-container">
                            <i class="bi bi-shield-check"></i>
                        </div>
                        <h3 class="mb-3">Secure Platform</h3>
                        <p class="text-muted mb-4">Enterprise-grade security for your peace of mind</p>
                        <a href="#" class="btn btn-primary">Learn More</a>
                    </div>
                </div>
            </div>

            <!-- Slide 3 -->
            <div class="carousel-item">
                <div class="card-slide">
                    <div class="intro-card">
                        <div class="icon-container">
                            <i class="bi bi-graph-up"></i>
                        </div>
                        <h3 class="mb-3">Growth Analytics</h3>
                        <p class="text-muted mb-4">Track your progress with advanced metrics</p>
                        <a href="#" class="btn btn-primary">View Stats</a>
                    </div>
                </div>
            </div>

            <!-- Slide 4 -->
            <div class="carousel-item">
                <div class="card-slide">
                    <div class="intro-card">
                        <div class="icon-container">
                            <i class="bi bi-headset"></i>
                        </div>
                        <h3 class="mb-3">24/7 Support</h3>
                        <p class="text-muted mb-4">Round-the-clock customer service</p>
                        <a href="#" class="btn btn-primary">Contact Us</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#cardCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#cardCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</section>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>