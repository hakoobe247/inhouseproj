<?php



function setRate(){


}


function getRate(){


}

function setSpread(){


}


function getSpread(){

    
}


?>