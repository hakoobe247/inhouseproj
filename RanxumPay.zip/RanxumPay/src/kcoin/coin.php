<?php


function setCoinWindow($coinWindowStart, $coinWindowEnd) {
    $_SESSION['coinWindowStart'] = $coinWindowStart;
    $_SESSION['coinWindowEnd'] = $coinWindowEnd;

  
}

function getCoinWindow() {
    
    if (isset($_SESSION['coinWindowStart']) && isset($_SESSION['coinWindowEnd'])) {
        return true;
    } else {
        return false;
    }
}

function createCoin($coinBatch, $coinValue, $coinWindow) {
    
    $coin = array(
        'coinName' => $coinName,
        'coinValue' => $coinValue
    );
    return $coin;
}









?>