<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exchange Order Summary</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .summary-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 600px;
            transition: transform 0.3s ease;
        }
        .status-icon {
            font-size: 2.5rem;
            animation: bounce 1s ease;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
    </style>
</head>
<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center">

<div class="summary-card p-4 m-3">
    <!-- Header -->
    <div class="text-center mb-4">
        <i class="bi bi-check-circle-fill status-icon text-primary"></i>
        <h2 class="text-primary mt-3">Exchange Complete</h2>
        <p class="text-muted">Your currency exchange was successful</p>
    </div>

    <!-- Summary Details -->
    <div class="row g-4 mb-4">
        <!-- From Currency -->
        <div class="col-6">
            <div class="d-flex align-items-center">
                <i class="bi bi-currency-dollar fs-4 text-primary me-3"></i>
                <div>
                    <div class="text-muted small">From</div>
                    <div class="h5 mb-0">1,000.00 USD</div>
                </div>
            </div>
        </div>

        <!-- To Currency -->
        <div class="col-6">
            <div class="d-flex align-items-center">
                <i class="bi bi-currency-euro fs-4 text-primary me-3"></i>
                <div>
                    <div class="text-muted small">To</div>
                    <div class="h5 mb-0">915.00 EUR</div>
                </div>
            </div>
        </div>

        <!-- Exchange Rate -->
        <div class="col-6">
            <div class="d-flex align-items-center">
                <i class="bi bi-graph-up fs-4 text-primary me-3"></i>
                <div>
                    <div class="text-muted small">Exchange Rate</div>
                    <div class="h5 mb-0">1 USD = 0.915 EUR</div>
                </div>
            </div>
        </div>

        <!-- Fees -->
        <div class="col-6">
            <div class="d-flex align-items-center">
                <i class="bi bi-cash-coin fs-4 text-primary me-3"></i>
                <div>
                    <div class="text-muted small">Fees</div>
                    <div class="h5 mb-0">$5.00</div>
                </div>
            </div>
        </div>

        <!-- Total -->
        <div class="col-12">
            <div class="d-flex align-items-center justify-content-between bg-primary bg-opacity-10 p-3 rounded">
                <div class="d-flex align-items-center">
                    <i class="bi bi-wallet2 fs-4 text-primary me-3"></i>
                    <div>
                        <div class="text-muted small">Total Received</div>
                        <div class="h4 mb-0 text-primary">915.00 EUR</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Transaction Details -->
    <div class="alert alert-primary">
        <div class="row">
            <div class="col-md-6">
                <i class="bi bi-clock-history me-2"></i>
                <span class="text-muted">Date:</span> 25 Oct 2023
            </div>
            <div class="col-md-6">
                <i class="bi bi-hash me-2"></i>
                <span class="text-muted">Reference:</span> #FX-4890234
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <div class="d-grid gap-3 mt-4">
        <button class="btn btn-primary btn-lg">
            <i class="bi bi-download me-2"></i>
            Download Receipt
        </button>
        <a href="#" class="btn btn-outline-primary">
            <i class="bi bi-arrow-left me-2"></i>
            Back to Exchange
        </a>
    </div>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>