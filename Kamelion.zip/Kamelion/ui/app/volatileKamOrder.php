<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KamCoin Exchanges</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .exchange-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 800px;
        }
        .crypto-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            color: #0d6efd;
        }
        .coming-soon {
            background: rgba(13, 110, 253, 0.1);
            border-radius: 10px;
        }
    </style>
</head>
<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center">

<div class="exchange-card p-4 m-3">
    <!-- Header -->
    <div class="text-center mb-4">
        <h2 class="text-primary">
            <i class="bi bi-currency-bitcoin me-2"></i>
            KamCoin Exchanges
        </h2>
        <p class="text-muted">Where to buy and trade KamCoin</p>
    </div>

    <!-- Exchange List -->
    <div class="row g-4">
        <!-- Solana -->
        <div class="col-md-6">
            <div class="d-flex align-items-center p-3 border rounded">
                <div class="crypto-icon me-3">
                    <i class="bi bi-currency-bitcoin"></i>
                </div>
                <div>
                    <h5 class="mb-1">Solana Blockchain</h5>
                    <p class="text-muted small mb-0">Trade KamCoin on Solana DEXs</p>
                </div>
            </div>
        </div>

        <!-- Ethereum -->
        <div class="col-md-6">
            <div class="d-flex align-items-center p-3 border rounded">
                <div class="crypto-icon me-3">
                    <i class="bi bi-currency-ethereum"></i>
                </div>
                <div>
                    <h5 class="mb-1">Ethereum Network</h5>
                    <p class="text-muted small mb-0">Available on major Ethereum exchanges</p>
                </div>
            </div>
        </div>

        <!-- Pi Network -->
        <div class="col-md-6">
            <div class="d-flex align-items-center p-3 border rounded">
                <div class="crypto-icon me-3">
                    <i class="bi bi-currency-yen"></i>
                </div>
                <div>
                    <h5 class="mb-1">Pi Blockchain</h5>
                    <p class="text-muted small mb-0">Coming soon to Pi Network</p>
                </div>
            </div>
        </div>

        <!-- Coming Soon -->
        <div class="col-12">
            <div class="coming-soon p-3 text-center">
                <i class="bi bi-hourglass-split me-2"></i>
                More exchange listings coming soon!
            </div>
        </div>
    </div>

    <!-- Additional Information -->
    <div class="alert alert-primary mt-4">
        <div class="row">
            <div class="col-md-6">
                <i class="bi bi-info-circle me-2"></i>
                Always verify contract addresses
            </div>
            <div class="col-md-6">
                <i class="bi bi-shield-check me-2"></i>
                Use only trusted exchanges
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>