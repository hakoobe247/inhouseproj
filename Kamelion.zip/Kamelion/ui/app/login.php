<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Fluid Login Form</title>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom CSS -->
  <style>
    body {
      background-color: #f8f9fa;
    }
    .login-section {
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #f8f9fa;
    }
    .login-form {
      background: white;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 400px;
    }
  </style>
</head>
<body>

  <!-- Fluid Login Section -->
  <section class="login-section">
    <div class="login-form">
      <h2 class="text-center mb-4">Login</h2>
      <form>
        <!-- Username Field -->
        <div class="mb-3">
          <br>
          <input type="text" class="form-control" id="username" placeholder="Enter your username" required>
        </div>

        <!-- Password Field -->
        <div class="mb-3">
          <br>
          <input type="password" class="form-control" id="password" placeholder="Enter your password" required>
        </div>

        <!-- Remember Me Checkbox -->
        <div class="mb-3 form-check">
          <input type="checkbox" class="form-check-input" id="rememberMe">
          <label class="form-check-label" for="rememberMe">Remember me</label>
        </div>

        <!-- Login Button -->
        <button type="submit" class="btn btn-primary w-100">Login</button>
        <br><br>
        <p>Don't have an account? <a href="register.php">Register</a></p>
       

        <!-- Forgot Password Link -->
        <p class="text-center mt-3">
          <a href="forgotpword.php" class="text-decoration-none">Forgot password?</a>
        </p>
      </form>
    </div>
  </section>

  <!-- Bootstrap 5 JS and dependencies -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>