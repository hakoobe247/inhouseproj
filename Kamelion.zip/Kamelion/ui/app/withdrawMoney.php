<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdraw Money</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .withdraw-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        .form-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #0d6efd;
            z-index: 2;
        }
        .form-input {
            padding-left: 45px !important;
        }
        .balance-display {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
        }
    </style>
</head>
<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center">

<div class="withdraw-card p-4 m-3">
    <!-- Header -->
    <div class="text-center mb-4">
        <h2 class="text-primary">
            <i class="bi bi-cash-coin me-2"></i>
            Withdraw Money
        </h2>
        <p class="text-muted">Transfer funds to your bank account</p>
    </div>

    <!-- Withdraw Form -->
    <form>
        <div class="row g-3">
            <!-- Balance Display -->
            <div class="col-12">
                <div class="balance-display">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="text-muted small">Available Balance</div>
                            <div class="h3 text-primary">$1,250.00</div>
                        </div>
                        <i class="bi bi-wallet2 fs-3 text-primary"></i>
                    </div>
                </div>
            </div>

            <!-- Amount Input -->
            <div class="col-12 position-relative">
                <i class="bi bi-cash-stack form-icon"></i>
                <input type="number" class="form-control form-input" placeholder="Withdrawal Amount" required>
            </div>

            <!-- Bank Account Selection -->
            <div class="col-12 position-relative">
                <i class="bi bi-bank form-icon"></i>
                <select class="form-select form-input" required>
                    <option value="" selected>Select Bank Account</option>
                    <option>Bank of America (••• 3456)</option>
                    <option>Chase Bank (••• 7890)</option>
                    <!-- Add more bank accounts -->
                </select>
            </div>

            <!-- Currency Selection -->
            <div class="col-12 position-relative">
                <i class="bi bi-currency-exchange form-icon"></i>
                <select class="form-select form-input" required>
                    <option value="" selected>Select Currency</option>
                    <option value="USD">USD - US Dollar</option>
                    <option value="EUR">EUR - Euro</option>
                    <option value="GBP">GBP - British Pound</option>
                    <!-- Add more currencies -->
                </select>
            </div>

            <!-- Fee Information -->
            <div class="col-12">
                <div class="alert alert-primary">
                    <div class="row">
                        <div class="col-6">
                            <i class="bi bi-percent me-2"></i>
                            Fee: $5.00
                        </div>
                        <div class="col-6">
                            <i class="bi bi-calculator me-2"></i>
                            Total: $1,245.00
                        </div>
                    </div>
                </div>
            </div>

            <!-- Security Info -->
            <div class="col-12">
                <div class="alert alert-primary">
                    <i class="bi bi-shield-check me-2"></i>
                    Your transaction is securely encrypted
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="col-12">
                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="bi bi-check-circle me-2"></i>
                    Confirm Withdrawal
                </button>
                <button type="reset" class="btn btn-outline-primary w-100 mt-2">
                    <i class="bi bi-x-circle me-2"></i>
                    Cancel
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>