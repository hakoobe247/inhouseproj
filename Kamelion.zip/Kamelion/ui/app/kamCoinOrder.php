<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crypto Order Form</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .crypto-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        .form-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #0d6efd;
            z-index: 2;
        }
        .crypto-select {
            padding-left: 45px !important;
        }
        .order-type-btn {
            flex: 1;
            border: 1px solid #dee2e6;
            padding: 0.75rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .order-type-btn.active {
            border-color: #0d6efd;
            background: rgba(13, 110, 253, 0.1);
        }
    </style>
</head>
<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center">

<div class="crypto-card p-4 m-3">
    <!-- Header -->
    <div class="text-center mb-4">
        <h2 class="text-primary">
            <i class="bi bi-currency-bitcoin me-2"></i>
            Crypto Trading
        </h2>
        <p class="text-muted">Buy and sell cryptocurrencies instantly</p>
    </div>

    <!-- Order Form -->
    <form>
        <div class="row g-3">
            <!-- Order Type Toggle -->
            <div class="col-12">
                <div class="d-flex gap-2">
                    <div class="order-type-btn active" data-type="buy">
                        <i class="bi bi-arrow-up-circle text-success"></i>
                        <div class="small">Buy</div>
                    </div>
                    <div class="order-type-btn" data-type="sell">
                        <i class="bi bi-arrow-down-circle text-danger"></i>
                        <div class="small">Sell</div>
                    </div>
                </div>
            </div>

            <!-- Crypto Selection -->
            <div class="col-12 position-relative">
                <i class="bi bi-currency-bitcoin form-icon"></i>
                <select class="form-select crypto-select" required>
                    <option value="" selected>Select Crypto</option>
                    <option value="BTC">BTC - Bitcoin</option>
                    <option value="ETH">ETH - Ethereum</option>
                    <option value="BNB">BNB - Binance Coin</option>
                    <option value="XRP">XRP - Ripple</option>
                    <option value="ADA">ADA - Cardano</option>
                    <!-- Add more cryptocurrencies -->
                </select>
            </div>

            <!-- Amount Input -->
            <div class="col-12 position-relative">
                <i class="bi bi-cash form-icon"></i>
                <input type="number" class="form-control" placeholder="Amount" required>
            </div>

            <!-- Order Type -->
            <div class="col-12 position-relative">
                <i class="bi bi-gear form-icon"></i>
                <select class="form-select crypto-select" required>
                    <option value="" selected>Order Type</option>
                    <option>Market</option>
                    <option>Limit</option>
                    <option>Stop-Limit</option>
                </select>
            </div>

            <!-- Price Input -->
            <div class="col-12 position-relative">
                <i class="bi bi-graph-up form-icon"></i>
                <input type="number" class="form-control" placeholder="Price (optional)">
            </div>

            <!-- Market Data -->
            <div class="col-12">
                <div class="alert alert-primary p-2">
                    <div class="row text-center">
                        <div class="col-4">
                            <small class="text-muted">Current Price</small>
                            <div class="fw-bold">$34,500.00</div>
                        </div>
                        <div class="col-4">
                            <small class="text-muted">24h Change</small>
                            <div class="fw-bold text-success">+2.45%</div>
                        </div>
                        <div class="col-4">
                            <small class="text-muted">24h Volume</small>
                            <div class="fw-bold">$12.4B</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Wallet Balance -->
            <div class="col-12">
                <div class="d-flex justify-content-between text-muted small">
                    <span><i class="bi bi-wallet2 me-1"></i>Available: 0.5234 BTC</span>
                    <span>≈ $18,045.50</span>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="col-12 mt-3">
                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="bi bi-lightning-charge me-2"></i>
                    Place Order
                </button>
                <button type="reset" class="btn btn-outline-primary w-100 mt-2">
                    <i class="bi bi-x-circle me-2"></i>
                    Cancel
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
<script>
    // Order type toggle
    const orderTypeButtons = document.querySelectorAll('.order-type-btn');
    orderTypeButtons.forEach(button => {
        button.addEventListener('click', function() {
            orderTypeButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
</script>
</body>
</html>