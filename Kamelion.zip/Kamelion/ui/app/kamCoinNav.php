<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page Navigator Cards</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .nav-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            cursor: pointer;
            height: 100%;
        }
        .nav-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
        }
        .nav-card .icon-wrapper {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1.5rem;
        }
        .prev-card .icon-wrapper {
            background: rgba(13, 110, 253, 0.1);
            color: #0d6efd;
        }
        .next-card .icon-wrapper {
            background: rgba(25, 135, 84, 0.1);
            color: #198754;
        }
    </style>
</head>
<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center">

<div class="container">
    <div class="row g-4">
        <!-- Previous Card -->
     <div class="col-md-6" id="kamC"> 
            <div class="nav-card prev-card p-4">
                <div class="icon-wrapper">
                    <i class="bi bi-arrow-left-circle fs-3"></i>
                </div>
                <h3 class="mb-3">KamCoin (Stable)</h3>
                <p class="text-muted mb-4">Stable Investment Token with a fixed return on investment</p>
                <div class="d-flex align-items-center text-primary">
                    <span class="me-2">Proceed</span>
                    <i class="bi bi-arrow-right"></i>
                </div>
            </div> 
        </div> 

        <script>
document.getElementById("kamC").addEventListener("click", function() {
  window.location.href = "kamCoinOrder.php";
});

        </script>

        <!-- Next Card -->
        <div class="col-md-6" id="kamCV">
            <div class="nav-card next-card p-4">
                <div class="icon-wrapper">
                    <i class="bi bi-arrow-right-circle fs-3"></i>
                </div>
                <h3 class="mb-3">KamCoin (Volatile)</h3>
                <p class="text-muted mb-4">High Risk Token (follows market trends)  </p>
                <div class="d-flex align-items-center text-success">
                    <span class="me-2">I'm aware proceed?</span>
                    <i class="bi bi-arrow-right"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById("kamCV").addEventListener("click", function() {
  window.location.href = "volatileKamOrder.php";
});

        </script>


<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
<script>
    // Add click handlers
    document.querySelector('.prev-card').addEventListener('click', function() {
        console.log('Previous card clicked');
        // Add your navigation logic here
    });

    document.querySelector('.next-card').addEventListener('click', function() {
        console.log('Next card clicked');
        // Add your navigation logic here
    });
</script>
</body>
</html>