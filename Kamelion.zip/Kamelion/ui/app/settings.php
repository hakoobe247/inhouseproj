<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KYC Settings</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .settings-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 800px;
        }
        .settings-item {
            padding: 1rem;
            border-bottom: 1px solid #dee2e6;
            transition: all 0.3s ease;
        }
        .settings-item:hover {
            background: #f8f9fa;
        }
        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.875rem;
        }
        .status-badge.verified {
            background: rgba(25, 135, 84, 0.1);
            color: #198754;
        }
        .status-badge.pending {
            background: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        .status-badge.unverified {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
    </style>
</head>
<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center">

<div class="settings-card p-4 m-3">
    <!-- Header -->
    <div class="text-center mb-4">
        <h2 class="text-primary">
            <i class="bi bi-gear-wide-connected me-2"></i>
            KYC Settings
        </h2>
        <p class="text-muted">Manage your account verification settings</p>
    </div>

    <!-- KYC Settings List -->
    <div class="list-group">
        <!-- Personal Information -->
        <div class="settings-item d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <i class="bi bi-person fs-4 text-primary me-3"></i>
                <div>
                    <h5 class="mb-1">Personal Information</h5>
                    <p class="text-muted small mb-0">Name, Date of Birth, Address</p>
                </div>
            </div>
            <span class="status-badge verified">
                <i class="bi bi-check-circle me-1"></i>
                Verified
            </span>
        </div>

        <!-- Identity Verification -->
        <div class="settings-item d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <i class="bi bi-person-badge fs-4 text-primary me-3"></i>
                <div>
                    <h5 class="mb-1">Identity Verification</h5>
                    <p class="text-muted small mb-0">Government-issued ID</p>
                </div>
            </div>
            <span class="status-badge pending">
                <i class="bi bi-hourglass-split me-1"></i>
                Pending Review
            </span>
        </div>

        <!-- Address Verification -->
        <div class="settings-item d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <i class="bi bi-house fs-4 text-primary me-3"></i>
                <div>
                    <h5 class="mb-1">Address Verification</h5>
                    <p class="text-muted small mb-0">Proof of residence</p>
                </div>
            </div>
            <span class="status-badge unverified">
                <i class="bi bi-exclamation-circle me-1"></i>
                Not Verified
            </span>
        </div>

        <!-- Financial Information -->
        <div class="settings-item d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <i class="bi bi-bank fs-4 text-primary me-3"></i>
                <div>
                    <h5 class="mb-1">Financial Information</h5>
                    <p class="text-muted small mb-0">Bank account details</p>
                </div>
            </div>
            <span class="status-badge verified">
                <i class="bi bi-check-circle me-1"></i>
                Verified
            </span>
        </div>
    </div>

    <!-- Additional Information -->
    <div class="alert alert-primary mt-4">
        <div class="row">
            <div class="col-md-6">
                <i class="bi bi-info-circle me-2"></i>
                Complete KYC for full account access
            </div>
            <div class="col-md-6">
                <i class="bi bi-shield-check me-2"></i>
                Your data is securely encrypted
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>