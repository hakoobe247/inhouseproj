<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaction Failed</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .error-section {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .error-card {
            max-width: 500px;
            border: none;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .error-icon {
            font-size: 4rem;
            color: #dc3545;
            animation: shake 1.5s infinite;
        }
        @keyframes shake {
            0% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            50% { transform: translateX(5px); }
            75% { transform: translateX(-5px); }
            100% { transform: translateX(0); }
        }
    </style>
</head>
<body>

<section class="error-section container-fluid d-flex align-items-center justify-content-center min-vh-100 p-3">
    <div class="error-card bg-white p-5 text-center">
        <!-- Error Icon -->
        <div class="mb-4">
            <i class="bi bi-x-circle-fill error-icon"></i>
        </div>
        
        <!-- Error Message -->
        <h1 class="text-danger mb-3">Transaction Failed</h1>
        <p class="text-muted mb-4">We're unable to process your payment at this time.</p>
        
        <!-- Details -->
        <div class="alert alert-light text-start mb-4">
            <h5 class="alert-heading"><i class="bi bi-info-circle me-2"></i>Possible reasons:</h5>
            <ul class="mb-0">
                <li>Insufficient funds</li>
                <li>Invalid card details</li>
                <li>Network connectivity issues</li>
                <li>Transaction limit exceeded</li>
            </ul>
        </div>
        
        <!-- Action Buttons -->
        <div class="d-grid gap-3">
            <button class="btn btn-danger btn-lg">
                <i class="bi bi-credit-card me-2"></i>
                Try Again
            </button>
            <a href="#" class="btn btn-outline-secondary">
                <i class="bi bi-headset me-2"></i>
                Contact Support
            </a>
        </div>
    </div>
</section>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>