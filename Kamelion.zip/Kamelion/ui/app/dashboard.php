<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Transfer Wallet Dashboard</title>
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome for Icons -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <style>
    body {
      background-color: white;
    }
    .sidebar {
      width: 250px;
      height: 100vh;
      position: fixed;
      top: 0;
      left: -250px;
      background-color: #0d6efd; /* Blue theme */
      transition: left 0.3s;
    }
    .sidebar.active {
      left: 0;
    }
    .sidebar .nav-link {
      color: white;
    }
    .sidebar .nav-link:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }
    .bottom-bar {
      position: fixed;
      bottom: 0;
      width: 100%;
      background-color: #0d6efd; /* Blue theme */
      display: flex;
      justify-content: space-around;
      padding: 10px;
      box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.1);
    }
    .bottom-bar .icon {
      font-size: 24px;
      color: white;
      cursor: pointer;
    }
    .main-content {
      margin-left: 0;
      padding: 20px;
      transition: margin-left 0.3s;
    }
    .main-content.active {
      margin-left: 250px;
    }
    .card {
      border: none;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    .card-title {
      color: #0d6efd; /* Blue theme */
    }
    .table {
      margin-top: 20px;
    }
    .table th {
      color: #0d6efd; /* Blue theme */
    }
  </style>
</head>
<body>

  <!-- Sidebar -->
  <div class="sidebar" id="sidebar">
    <div class="p-3">
      <h5 class="text-white">Menu</h5>
      <ul class="nav flex-column">
        <li class="nav-item"><a href="dashboard.php" class="nav-link">Home</a></li>
        <li class="nav-item"><a href="#" class="nav-link">Profile</a></li>
        <li class="nav-item"><a href="settings.php" class="nav-link">Settings</a></li>
        <li class="nav-item"><a href="contactSupport.php" class="nav-link">Support</a></li>
      </ul>
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content" id="mainContent">
    <!-- Hamburger Toggle -->
    <button class="btn btn-primary mt-3 ms-3" id="sidebarToggle">
      <i class="fas fa-bars"></i>
    </button>

    <!-- Welcome Message and Balance -->
    <div class="container mt-5">
      <h1 class="text-primary">Welcome, User!</h1>
      <div class="card mt-3">
        <div class="card-body">
          <h5 class="card-title">Main Balance</h5>
          <p class="card-text fs-3 text-primary">$1,250.00</p>
        </div>
        <div class="card-body">
          <h5 class="card-title">KU Balance</h5>
          <p class="card-text fs-3 text-primary">$1,250.00</p>
        </div>
      </div>
    </div>

    <!-- Past Transaction History -->
    <div class="container mt-5">
      <h3 class="text-primary">Transaction History</h3>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Date</th>
            <th>Description</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>2023-10-01</td>
            <td>Payment to John Doe</td>
            <td class="text-danger">-$50.00</td>
          </tr>
          <tr>
            <td>2023-09-28</td>
            <td>Deposit</td>
            <td class="text-success">+$500.00</td>
          </tr>
          <tr>
            <td>2023-09-25</td>
            <td>Withdrawal</td>
            <td class="text-danger">-$200.00</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Bottom Bar -->
  <div class="bottom-bar">
  <a href="fxEntries.php"><div class="icon"><i class="fas fa-exchange-alt" ></i>  </div></a>
  <a href="withdrawMoney.php"><div class="icon"><i class="fas fa-money-bill-wave"></i></div></a>
  <a href="kamCoinNav.php"><div class="icon"><i class="fab fa-bitcoin"></i></div></a>
  <a href="addMoney.php"><div class="icon"><i class="fas fa-coins"></i></div></a>
  <a href="addMoney.php"><div class="icon"><i class="fas fa-wallet"></i></div></a>
  </div>

  <!-- Bootstrap 5 JS and Popper.js -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
  <script>
    // Toggle Sidebar
    document.getElementById('sidebarToggle').addEventListener('click', function () {
      document.getElementById('sidebar').classList.toggle('active');
      document.getElementById('mainContent').classList.toggle('active');
    });
  </script>
</body>
</html>