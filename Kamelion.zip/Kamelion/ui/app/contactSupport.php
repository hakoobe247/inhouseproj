<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Support</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .support-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        .form-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #0d6efd;
            z-index: 2;
        }
        .form-input {
            padding-left: 45px !important;
        }
        .contact-info {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
        }
    </style>
</head>
<body class="bg-light min-vh-100 d-flex align-items-center justify-content-center">

<div class="support-card p-4 m-3">
    <!-- Header -->
    <div class="text-center mb-4">
        <h2 class="text-primary">
            <i class="bi bi-headset me-2"></i>
            Contact Support
        </h2>
        <p class="text-muted">We're here to help you 24/7</p>
    </div>

    <!-- Contact Form -->
    <form>
        <div class="row g-3">
            <!-- Name Input -->
            <div class="col-12 position-relative">
                <i class="bi bi-person form-icon"></i>
                <input type="text" class="form-control form-input" placeholder="Your Name" required>
            </div>

            <!-- Email Input -->
            <div class="col-12 position-relative">
                <i class="bi bi-envelope form-icon"></i>
                <input type="email" class="form-control form-input" placeholder="Email Address" required>
            </div>

            <!-- Subject Selection -->
            <div class="col-12 position-relative">
                <i class="bi bi-tag form-icon"></i>
                <select class="form-select form-input" required>
                    <option value="" selected>Select Subject</option>
                    <option>Account Issues</option>
                    <option>Payment Problems</option>
                    <option>Technical Support</option>
                    <option>General Inquiry</option>
                </select>
            </div>

            <!-- Message Input -->
            <div class="col-12 position-relative">
                <i class="bi bi-chat-dots form-icon"></i>
                <textarea class="form-control form-input" rows="4" placeholder="Your Message" required></textarea>
            </div>

            <!-- Contact Information -->
            <div class="col-12">
                <div class="contact-info">
                    <div class="row">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <i class="bi bi-telephone me-2"></i>
                            <span class="text-muted">Call us:</span>
                            <div class="h5 mb-0">+1 (800) 123-4567</div>
                        </div>
                        <div class="col-md-6">
                            <i class="bi bi-envelope me-2"></i>
                            <span class="text-muted">Email us:</span>
                            <div class="h5 mb-0">support@example.com</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="col-12">
                <button type="submit" class="btn btn-primary btn-lg w-100">
                    <i class="bi bi-send me-2"></i>
                    Send Message
                </button>
                <button type="reset" class="btn btn-outline-primary w-100 mt-2">
                    <i class="bi bi-x-circle me-2"></i>
                    Clear Form
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Bootstrap 5 JS and Popper.js -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
</body>
</html>